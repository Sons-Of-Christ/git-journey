﻿//--- KAMOGELO SEKHAOLELO ----
// ---- Lubanzi Assignment 1 --- Employee Registration and Login System ----
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// ============================================================
//  EMPLOYEE CLASS
//  internal: only accessible within this assembly (project)
// ============================================================
public class Employee
{
    // ---- Public properties (accessible from Program class) ----
    public int EmployeeID { get; private set; }   // private set = read-only from outside
    public string Name { get; set; }
    public string Surname { get; set; }
    public int Age { get; set; }
    public decimal Salary { get; set; }
    public string Role { get; set; }
    public string Username { get; set; }
    public bool IsActive { get; set; }

    // ---- Private field: password is sensitive, never exposed directly ----
    private string _password;

    // ---- Constructor ----
    public Employee(int id, string name, string surname, int age,
                    decimal salary, string role, string username, string password)
    {
        EmployeeID = id;
        Name = name;
        Surname = surname;
        Age = age;
        Salary = salary;
        Role = role;
        Username = username;
        _password = password;
        IsActive = true;
    }

    // ---- Public method to verify password without exposing the field ----
    public bool CheckPassword(string inputPassword)
    {
        return _password == inputPassword;
    }

    // ---- Display profile (no password shown) ----
    public void DisplayProfile()
    {
        Console.WriteLine("\nYour Profile:");
        Console.WriteLine($"  - Name        : {Name} {Surname}");
        Console.WriteLine($"  - Age         : {Age}");
        Console.WriteLine($"  - Role        : {Role}");
        Console.WriteLine($"  - Salary      : R{Salary:N2}");
        Console.WriteLine($"  - Status      : {(IsActive ? "Active" : "Inactive")}");
    }
}


// ============================================================
//  PROGRAM CLASS  -  main menu + all logic lives here
// ============================================================
internal class Program
{
    // List<Employee> stores all registered employees in memory
    private static List<Employee> employees = new List<Employee>();
    private static int nextID = 1001;   // auto-increment Employee ID

    // ============================================================
    //  Employee DATA  -  5 existing South African employees
    //  3 male, 2 female with SA names
    //  All share password: Pass@1234  (for easy testing)
    // ============================================================
    static void SeedEmployees()
    {
        employees.Add(new Employee(nextID++, "Sipho", "Dlamini", 34, 52000.00m, "Manager", "sipho.dlamini", "Pass@1234"));
        employees.Add(new Employee(nextID++, "Naledi", "Mokoena", 28, 38500.50m, "Developer", "naledi.mokoena", "Pass@1234"));
        employees.Add(new Employee(nextID++, "Thabo", "Nkosi", 41, 67000.00m, "Sales", "thabo.nkosi", "Pass@1234"));
        employees.Add(new Employee(nextID++, "Zanele", "Khumalo", 25, 31000.75m, "Developer", "zanele.khumalo", "Pass@1234"));
        employees.Add(new Employee(nextID++, "Lethiwe", "Ntanzi", 30, 45500.00m, "Sales", "lethiwe.ntanzi", "Pass@1234"));
    }

    // ============================================================
    //  READ PASSWORD  -  masks input as ****
    // ============================================================
    static string ReadPassword()
    {
        string password = "";
        ConsoleKeyInfo key;

        do
        {
            key = Console.ReadKey(intercept: true); // intercept: true = don't print the character

            if (key.Key != ConsoleKey.Enter && key.Key != ConsoleKey.Backspace)
            {
                password += key.KeyChar;
                Console.Write("*");
            }
            else if (key.Key == ConsoleKey.Backspace && password.Length > 0)
            {
                password = password.Substring(0, password.Length - 1);
                Console.Write("\b \b"); // erase the last * on screen
            }
        }
        while (key.Key != ConsoleKey.Enter);

        Console.WriteLine(); // move to next line after Enter
        return password;
    }

    // ============================================================
    //  MAIN
    // ============================================================
    static void Main(string[] args)
    {
        // Load the 5 existing South African employees on startup
        SeedEmployees();

        Console.WriteLine("=== Welcome to the Employee System ===\n");

        bool running = true;
        while (running)
        {
            ShowMainMenu();
            string choice = Console.ReadLine();

            if (choice == "1")
                RegisterEmployee();
            else if (choice == "2")
                LoginEmployee();
            else if (choice == "3")
                ViewAllEmployees();
            else if (choice == "4")
            {
                Console.WriteLine("\nGoodbye!");
                running = false;
            }
            else
            {
                Console.WriteLine("\n[!] Invalid option. Please enter 1-4.\n");
            }
        }
    }

    // ---- MAIN MENU ----
    static void ShowMainMenu()
    {
        Console.WriteLine("=== EMPLOYEE SYSTEM ===");
        Console.WriteLine("1. Register New Employee");
        Console.WriteLine("2. Login");
        Console.WriteLine("3. View All Employees");
        Console.WriteLine("4. Exit");
        Console.Write("\nEnter your choice: ");
    }


    // ============================================================
    //  REGISTER
    // ============================================================
    static void RegisterEmployee()
    {
        Console.WriteLine("\n--- Register New Employee ---");

        // -- Name --
        string name = ReadNonEmpty("Enter your name: ");

        // -- Surname --
        string surname = ReadNonEmpty("Enter your surname: ");

        // -- Age: must be 18 or older --
        int age = 0;
        while (true)
        {
            Console.Write("Enter your age: ");
            string ageInput = Console.ReadLine();

            if (!int.TryParse(ageInput, out age) || age <= 0)
            {
                Console.WriteLine("[!] Please enter a valid age.");
                continue;
            }

            // if statement: age validation
            if (age < 18)
            {
                Console.WriteLine("[!] You must be 18 or older to register.");
                continue;
            }
            break;
        }

        // -- Salary: must be a positive decimal --
        decimal salary = 0;
        while (true)
        {
            Console.Write("Enter your salary: ");
            string salInput = Console.ReadLine();

            if (!decimal.TryParse(salInput, out salary) || salary < 0)
            {
                Console.WriteLine("[!] Please enter a valid salary (e.g. 45000.50).");
                continue;
            }
            break;
        }

        // -- Role --
        string role = ReadNonEmpty("Enter your role (e.g. Developer, Manager, Sales): ");

        // -- Username: must be unique -- (e.g GettoFabulous45)
        string username = "";
        while (true)
        {
            username = ReadNonEmpty("Create username: ");

            // if statement: check username uniqueness
            if (UsernameExists(username))
            {
                Console.WriteLine("[!] That username is already taken. Try another.");
                continue;
            }
            break;
        }

        // -- Password + Confirm Password --
        string password = "";
        while (true)
        {
            Console.Write("Create password: ");
            password = ReadPassword();

            // if statement: password cannot be empty
            if (string.IsNullOrWhiteSpace(password))
            {
                Console.WriteLine("[!] Password cannot be empty.");
                continue;
            }

            Console.Write("Confirm password: ");
            string confirmPassword = ReadPassword();

            // if statement: passwords must match
            if (password != confirmPassword)
            {
                Console.WriteLine("[!] Passwords do not match. Please try again.\n");
                continue;
            }

            // passwords match - then exit the loop
            break;
        }

        // Create and store the new employee on computer memory (List<Employee>)
        Employee newEmp = new Employee(nextID, name, surname, age,
                                       salary, role, username, password);
        employees.Add(newEmp);

        Console.WriteLine("\nEmployee registered successfully!");
        Console.WriteLine($"Your Employee ID: {nextID}\n");
        nextID++;   // increment for next registration
    }


    // ============================================================
    //  LOGIN
    // ============================================================
    static void LoginEmployee()
    {
        Console.WriteLine("\n--- Login ---");

        string username = ReadNonEmpty("Enter username: ");
        Console.Write("Enter password: ");
        string password = ReadPassword();

        // Search the List for a matching username
        Employee found = null;
        foreach (Employee emp in employees)
        {
            if (emp.Username == username)
            {
                found = emp;
                break;
            }
        }

        // if statement: check if employee exists
        if (found == null)
        {
            Console.WriteLine("[!] Username not found. Please register first.\n");
            return;
        }

        // if statement: verify password
        if (!found.CheckPassword(password))
        {
            Console.WriteLine("[!] Incorrect password. Please try again.\n");
            return;
        }

        // Successful login
        Console.WriteLine("\n=== LOGIN SUCCESSFUL ===");
        Console.WriteLine($"Welcome back, {found.Name} {found.Surname}!");
        found.DisplayProfile();
        Console.WriteLine();
    }


    // ============================================================
    //  VIEW ALL EMPLOYEES
    // ============================================================
    static void ViewAllEmployees()
    {
        Console.WriteLine("\n--- All Registered Employees ---");

        // if statement: check if list is empty
        if (employees.Count == 0)
        {
            Console.WriteLine("[!] No employees registered yet.\n");
            return;
        }

        int count = 1;
        foreach (Employee emp in employees)
        {
            Console.WriteLine($"\n[{count}] {emp.Name} {emp.Surname} | Role: {emp.Role} | Active: {emp.IsActive}");
            count++;
        }
        Console.WriteLine();
    }


    // ============================================================
    //  HELPER METHODS
    // ============================================================

    // Keeps prompting until the user enters something non-empty
    static string ReadNonEmpty(string prompt)
    {
        string input = "";
        while (true)
        {
            Console.Write(prompt);
            input = Console.ReadLine();

            // if statement: empty input validation
            if (string.IsNullOrWhiteSpace(input))
            {
                Console.WriteLine("[!] This field cannot be empty.");
                continue;
            }
            break;
        }
        return input.Trim();
    }

    // Searches the employees List for an existing username
    static bool UsernameExists(string username)
    {
        foreach (Employee emp in employees)
        {
            if (emp.Username.ToLower() == username.ToLower())
                return true;
        }
        return false;
    }
}
