package OrangePacks;

import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;


public class ForgotPasswordTest {


		public static void main(String[] args)
		{
			// TODO Auto-generated method stub

			WebDriver driver = null;

			try {

				// Set Driver Path
				System.setProperty("webdriver.gecko.driver","C:\\geckodriver.exe");

				driver = new ChromeDriver();

				// Set up a wait object so we don't rely on fixed sleeps
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

				//1 Open OrangeHRM
				String baseUrl = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
				// 2 driver launches url from saved variable
				driver.get(baseUrl);
				// 3 driver makes screen max on your browser
				driver.manage().window().maximize();

				// 4 Verify the login page has loaded by waiting for the username field to appear
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username")));
				System.out.println("Login page loaded successfully.");

				// 5 driver locates the "Forgot your password?" link and clicks it
				driver.findElement(By.xpath("//p[text()='Forgot your password? ']")).click();

				// 6 Verify the Reset Password page has loaded
				WebElement resetHeader = wait.until(
						ExpectedConditions.visibilityOfElementLocated(By.xpath("//h6[text()='Reset Password']")));
				System.out.println("Forgot Password page loaded successfully.");

				// 7 driver locates the username field on the reset page and sends "Admin"
				driver.findElement(By.cssSelector("input[placeholder='Username']")).sendKeys("Admin");

				// 8 driver locates the Reset Password button and clicks it
				driver.findElement(By.xpath("//button[@type='submit']")).click();

				// 9 Verify the confirmation message is displayed after submitting
				WebElement confirmationTitle = wait.until(
						ExpectedConditions.visibilityOfElementLocated(
								//By.xpath("//h6[text()='Reset Password link sent successfully']")));
								By.xpath("/html/body/div/div[1]/div/div[1]/div/div[2]/div[2]/form/div[4]/p")));

				if (confirmationTitle.isDisplayed()) {
					// 10 Print success message to console
					System.out.println("TEST PASSED: Forgot Password flow completed successfully.");
				} else {
					System.out.println("TEST FAILED: Confirmation message not found.");
				}

			} catch (Exception e) {
				// Catches any element-not-found, timeout, or unexpected errors
				System.out.println("TEST FAILED: " + e.getMessage());

			} finally {
				// 11 Close the browser, whether the test passed or failed
				if (driver != null) {
					driver.quit();
				}
			}

		}

	}