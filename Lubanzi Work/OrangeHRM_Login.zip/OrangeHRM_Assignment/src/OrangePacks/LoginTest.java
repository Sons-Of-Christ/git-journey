package OrangePacks;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;


public class LoginTest {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub

		WebDriver driver = null;

		try {

			// Set Driver Path
			System.setProperty("webdriver.gecko.driver","C:\\geckodriver.exe");

			driver = new ChromeDriver();

			// Set up a wait object so we don't rely on fixed sleeps
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

			//1 Open OrangeHRM
			String baseUrl = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
			// 2 driver launches url from saved variable
			driver.get(baseUrl);
			// 3 driver makes screen max on your browser
			driver.manage().window().maximize();

			// 3.5 Verify the login page has loaded by waiting for the username field to appear
			WebElement usernameField = wait.until(
					ExpectedConditions.visibilityOfElementLocated(By.name("username")));
			System.out.println("Login page loaded successfully.");

			// 4 driver locates username field using name locator and sends "Admin" to be populated
			usernameField.sendKeys("Admin");
			// 5 driver locates password field locator and sends "admin123" to be populated
			driver.findElement(By.name("password")).sendKeys("admin123");
			// 6 driver locates login button and clicks it
			driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[3]/button")).click();

			// 7 Verify login was successful by waiting for the URL to change to the dashboard
			wait.until(ExpectedConditions.urlContains("/dashboard"));

			// 8 Verify the Dashboard header is visible as extra confirmation
			WebElement dashboardHeader = wait.until(
					ExpectedConditions.visibilityOfElementLocated(By.xpath("//h6[text()='Dashboard']")));

			if (dashboardHeader.isDisplayed() && driver.getCurrentUrl().contains("/dashboard")) {
				// 9 Print success message to console
				System.out.println("TEST PASSED: Login was successful.");
			} else {
				System.out.println("TEST FAILED: Dashboard not confirmed after login.");
			}

		} catch (Exception e) {
			// Catches any element-not-found, timeout, or unexpected errors
			System.out.println("TEST FAILED: " + e.getMessage());

		} finally {
			// 10 Close the browser, whether the test passed or failed
			if (driver != null) {
				driver.quit();
			}
		}

	}

}