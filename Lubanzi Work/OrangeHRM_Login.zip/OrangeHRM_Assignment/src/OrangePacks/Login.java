package OrangePacks;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class Login {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		// Set Driver Path
	System.setProperty("webdriver.gecko.driver","C:\\geckodriver.exe");
	
	WebDriver driver = new ChromeDriver();
	
	//1 Open OrangeHRM
	String baseUrl = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
	// 2 driver launches url from saved variable
	driver.get(baseUrl);
	// 3 driver makes screen max on your browser 
	driver.manage().window().maximize();
	// 4 driver locates username field using name locator and sends "Admin" to be populated
	driver.findElement(By.name("username")).sendKeys("Admin");
	// 5 driver locates password field locator and sends "admin123" to be populated
	driver.findElement(By.name("password")).sendKeys("admin123");
	// 6 driver locates password field locator and sends "admin123" to be populated
	driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[3]/button")).click();
	
	
	}

}
