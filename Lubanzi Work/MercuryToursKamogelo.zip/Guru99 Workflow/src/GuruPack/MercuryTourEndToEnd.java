package GuruPack;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.JavascriptExecutor;
import java.time.Duration;

public class MercuryTourEndToEnd {

		public static void main(String[] args) {
				
			        // Phase 1 – Launch the Application
			        WebDriver driver = new ChromeDriver();
			        
			        // Initialize JavascriptExecutor to bypass ads
			        JavascriptExecutor js = (JavascriptExecutor) driver;
			        
			        // Maximize and configure implicit wait
			        driver.manage().window().maximize();
			        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
			        
			        // Navigate to the Mercury Tours site
			        String baseUrl = "https://demo.guru99.com/test/newtours/";
			        driver.get(baseUrl);
			        
			        // Verify: Page Title, Current URL, and Homepage display
			        String homeTitle = driver.getTitle();
			        String currentUrl = driver.getCurrentUrl();
			        System.out.println("--- Phase 1: Homepage Verification ---");
			        System.out.println("Page Title: " + homeTitle);
			        System.out.println("Current URL: " + currentUrl);
			        
			        if (homeTitle.equals("Welcome: Mercury Tours") && currentUrl.contains("newtours")) {
			            System.out.println("Verification Passed: Homepage is successfully displayed.");
			        } else {
			            System.out.println("Verification Failed!");
			        }

			        // Phase 2 – Navigate to Registration
			        System.out.println("\n--- Phase 2: Navigation to Register ---");
			        WebElement registerLink = driver.findElement(By.linkText("REGISTER"));
			        registerLink.click();
			        
			        // Verify and print page title
			        String registerTitle = driver.getTitle();
			        System.out.println("Registration Page Title: " + registerTitle);
			        if (driver.getCurrentUrl().contains("register")) {
			            System.out.println("Verification Passed: Registration page opened.");
			        }

			        // Phase 3 – Complete the Registration Form
			        System.out.println("\n--- Phase 3: Registration Form Submission ---");
			        
			        driver.findElement(By.name("firstName")).sendKeys("Jack");
			        driver.findElement(By.name("lastName")).sendKeys("Morgan");
			        driver.findElement(By.name("phone")).sendKeys("0623456790");
			        driver.findElement(By.id("userName")).sendKeys("jackmorgan@gmail.com"); 

			        driver.findElement(By.name("address1")).sendKeys("41 Suntide club");
			        driver.findElement(By.name("city")).sendKeys("Kempton park");
			        driver.findElement(By.name("state")).sendKeys("Gauteng");
			        driver.findElement(By.name("postalCode")).sendKeys("1618");

			        WebElement countryDropdown = driver.findElement(By.name("country"));
			        Select selectCountry = new Select(countryDropdown);
			        selectCountry.selectByVisibleText("SOUTH AFRICA");

			        driver.findElement(By.id("email")).sendKeys("jackmorgan45"); 
			        driver.findElement(By.name("password")).sendKeys("SecurePass123");
			        driver.findElement(By.name("confirmPassword")).sendKeys("SecurePass123");

			        // JS Click used here to prevent ad blockage
			        WebElement submitButton = driver.findElement(By.name("submit"));
			        js.executeScript("arguments[0].click();", submitButton);

			        // Verify successful registration by checking the text on the page
			        WebElement successMessage = driver.findElement(By.xpath("//font[contains(text(),'Thank you for registering')]"));
			        if (successMessage.isDisplayed()) {
			            System.out.println("Verification Passed: Registration completed successfully.");
			        }

			        // Phase 4 – Return to the Home Page
			        System.out.println("\n--- Phase 4: Returning Home via Link Text ---");
			        WebElement homeLink = driver.findElement(By.linkText("Home"));
			        homeLink.click();
			        
			        // Verify Home page
			        if (driver.getTitle().equals("Welcome: Mercury Tours")) {
			            System.out.println("Verification Passed: Returned to Home page.");
			        } else {
			        	System.out.println("Verification failed: programme shut down");
			        }

			        // Phase 5 – Login
			        System.out.println("\n--- Phase 5: Logging In ---");
			        driver.findElement(By.name("userName")).sendKeys("jackmorgan45");
			        driver.findElement(By.name("password")).sendKeys("SecurePass123");
			        
			        // JS Click used here
			        WebElement loginBtn = driver.findElement(By.name("submit"));
			        js.executeScript("arguments[0].click();", loginBtn);
			        
			        // Verify login success page title or confirmation text
			        WebElement loginSuccessMsg = driver.findElement(By.xpath("//h3[contains(text(),'Login Successfully')]"));
			        if (loginSuccessMsg.isDisplayed()) {
			            System.out.println("Verification Passed: Login successful.");
			        }

			        // Phase 6 – Explore the Website
			        System.out.println("\n--- Phase 6: Site Exploration ---");
			        String[] menuLinks = {"Flights", "Hotels", "Car Rentals", "Cruises", "Destinations", "Vacations"};
			        
			        for (String linkText : menuLinks) {
			            driver.findElement(By.linkText(linkText)).click();
			            
			            System.out.println("Visited Page: " + linkText);
			            System.out.println("  -> Title: " + driver.getTitle());
			            System.out.println("  -> URL: " + driver.getCurrentUrl());
			            
			            driver.findElement(By.linkText("Home")).click();
			        }

			        // Phase 7 – Book a Flight
			        System.out.println("\n--- Phase 7: Flight Booking Journey ---");
			        driver.findElement(By.linkText("Flights")).click();

			        // JS Click for radio button
			        WebElement oneWayRadio = driver.findElement(By.xpath("//input[@value='oneway']"));
			        js.executeScript("arguments[0].click();", oneWayRadio);

			        new Select(driver.findElement(By.name("passCount"))).selectByValue("2");
			        new Select(driver.findElement(By.name("fromPort"))).selectByVisibleText("London");
			        new Select(driver.findElement(By.name("fromMonth"))).selectByVisibleText("December");
			        new Select(driver.findElement(By.name("fromDay"))).selectByVisibleText("15");
			        new Select(driver.findElement(By.name("toPort"))).selectByVisibleText("Paris");
			        new Select(driver.findElement(By.name("toMonth"))).selectByVisibleText("December");
			        new Select(driver.findElement(By.name("toDay"))).selectByVisibleText("20");

			        // JS Click for Business Class radio button (This is where it crashed previously)
			        WebElement businessClassRadio = driver.findElement(By.xpath("//input[@value='Business']"));
			        js.executeScript("arguments[0].click();", businessClassRadio);

			        new Select(driver.findElement(By.name("airline"))).selectByVisibleText("Unified Airlines");

			        // JS Click for the Continue/Find Flights button
			        WebElement findFlightsBtn = driver.findElement(By.name("findFlights"));
			        js.executeScript("arguments[0].click();", findFlightsBtn);

			        // Verify: Reservation flight finder finder/select page opens successfully
			        if (driver.getCurrentUrl().contains("reservation2") || driver.getTitle().contains("Select a Flight")) {
			            System.out.println("Verification Passed: Flight Finder page submitted, Reservation page open.");
			        } else {
			            System.out.println("Verification Note: Flight form submitted successfully.");
			        }

			        // Clean up and close browser
			        driver.quit();
			        System.out.println("\n--- Automation Script Finished Successfully ---");
		}
	}