using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieBookingSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            Theater theater = new Theater();
            bool running = true;

            Console.WriteLine("========================================");
            Console.WriteLine("      WELCOME TO LUBANZI CINEMAS");
            Console.WriteLine("========================================");

            while (running)
            {
                DisplayMenu();

                Console.Write("\nEnter your choice: ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        theater.DisplayAllMovies();
                        break;
                    case "2":
                        theater.BookTickets();
                        break;
                    case "3":
                        theater.ViewAllBookings();
                        break;
                    case "4":
                        theater.CancelBooking();
                        break;
                    case "5":
                        theater.SearchByGenre();
                        break;
                    case "6":
                        theater.ViewSnackMenu();
                        break;
                    case "7":
                        theater.ViewCancelledBookings();
                        break;
                    case "8":
                        running = false;
                        Console.WriteLine("\n  Thank you for visiting Lubanzi Cinemas. Goodbye!\n");
                        break;
                    default:
                        Console.WriteLine("\n  [!] Invalid option. Please enter 1–8.");
                        break;
                }

                if (running)
                {
                    Console.Write("\nPress Enter to return to the main menu...");
                    Console.ReadLine();
                    Console.Clear();
                }
            }
        }

        private static void DisplayMenu()
        {
            Console.WriteLine("\n========================================");
            Console.WriteLine("     MOVIE TICKET BOOKING SYSTEM");
            Console.WriteLine("========================================");
            Console.WriteLine("  1. View All Movies");
            Console.WriteLine("  2. Book Tickets");
            Console.WriteLine("  3. View Active Bookings");
            Console.WriteLine("  4. Cancel Booking");
            Console.WriteLine("  5. Search Movies by Genre");
            Console.WriteLine("  6. View Snack Bar Menu");
            Console.WriteLine("  7. View Cancelled Bookings");
            Console.WriteLine("  8. Exit");
            Console.WriteLine("========================================");
        }
    }
}
