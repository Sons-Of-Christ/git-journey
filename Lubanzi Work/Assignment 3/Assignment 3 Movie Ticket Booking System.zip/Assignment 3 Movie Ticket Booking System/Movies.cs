using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace MovieBookingSystem
{
    public class Movie
    {
        // Private fields
        private string title;
        private string genre;
        private int duration;
        private double price;
        private int availableSeats;

        // Public properties
        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        public string Genre
        {
            get { return genre; }
            set { genre = value; }
        }

        public int Duration
        {
            get { return duration; }
            set { duration = value; }
        }

        public double Price
        {
            get { return price; }
            set { price = value; }
        }

        public int AvailableSeats
        {
            get { return availableSeats; }
            set { availableSeats = value; }
        }

        // Constructor
        public Movie(string title, string genre, int duration, double price, int availableSeats)
        {
            this.title = title;
            this.genre = genre;
            this.duration = duration;
            this.price = price;
            this.availableSeats = availableSeats;
        }

        // Protected method - could be used by a derived class (e.g., PremiumMovie)
        protected string GetMovieSummary()
        {
            return $"{title} ({genre}) - {duration} mins";
        }

        // Internal method - accessible within the same assembly
        internal bool HasSeatsAvailable(int requested)
        {
            return availableSeats >= requested;
        }

        // Public display method
        public void DisplayInfo(int index)
        {
            Console.WriteLine($"  [{index}] {title}");
            Console.WriteLine($"      Genre    : {genre}");
            Console.WriteLine($"      Duration : {duration} minutes");
            Console.WriteLine($"      Price    : R{price:F2} per ticket");
            Console.WriteLine($"      Seats    : {availableSeats} available");
            Console.WriteLine();
        }
    }
}
