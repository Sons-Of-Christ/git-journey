using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieBookingSystem
{
    public class Theater
    {
        // Private fields
        private Movie[]   movies;           // Fixed-size array - movie catalog
        private Snack[]   snacks;           // Fixed-size array - snack catalog
        private ArrayList bookings;         // Dynamic list - active bookings
        private ArrayList cancelledBookings;// Dynamic list - cancelled bookings history
        private int       bookingCounter;

        // Constructor
        public Theater()
        {
            bookings          = new ArrayList();
            cancelledBookings = new ArrayList();
            bookingCounter    = 1000;
            InitialiseMovies();
            InitialiseSnacks();
            LoadPreloadedBookings();
            LoadCancelledBookings();
        }

        // ── Seed data ─────────────────────────────────────────────────

        private void InitialiseMovies()
        {
            movies = new Movie[]
            {
                new Movie("The Dark Knight",           "Action",  152, 120.00, 50),
                new Movie("Inception",                  "Sci-Fi",  148, 130.00, 40),
                new Movie("The Notebook",               "Romance", 123,  95.00, 60),
                new Movie("Get Out",                    "Horror",  104, 110.00, 35),
                new Movie("The Pursuit of Happyness",   "Drama",   117, 100.00, 45),
                new Movie("Avengers: Endgame",          "Action",  181, 150.00, 55),
                new Movie("Interstellar",               "Sci-Fi",  169, 135.00, 30)
            };
        }

        private void InitialiseSnacks()
        {
            snacks = new Snack[]
            {
                // Popcorn
                new Snack("S01", "Small Popcorn",        "Popcorn",  35.00),
                new Snack("S02", "Large Popcorn",        "Popcorn",  55.00),
                new Snack("S03", "Caramel Popcorn",      "Popcorn",  65.00),
                new Snack("S04", "Cheese Popcorn",       "Popcorn",  65.00),
                // Drinks
                new Snack("S05", "Small Cold Drink",     "Drinks",   30.00),
                new Snack("S06", "Large Cold Drink",     "Drinks",   45.00),
                new Snack("S07", "Bottled Water",        "Drinks",   20.00),
                new Snack("S08", "Hot Chocolate",        "Drinks",   40.00),
                // Snacks
                new Snack("S09", "Nachos & Cheese",      "Snacks",   60.00),
                new Snack("S10", "Hot Dog",              "Snacks",   55.00),
                new Snack("S11", "Chocolate Bar",        "Snacks",   25.00),
                new Snack("S12", "Gummy Bears",          "Snacks",   20.00),
                new Snack("S13", "Slushie",              "Drinks",   35.00),
            };
        }

        // 5 preloaded active bookings
        private void LoadPreloadedBookings()
        {
            // Preloaded booking 1 — Thabo, 2 tickets, The Dark Knight, Card, 10% discount
            Booking b1 = new Booking(GenerateBookingID(), movies[0], "Thabo Nkosi", 2, "Card", 10.0);
            b1.AddSnack(snacks[1], 2);  // 2x Large Popcorn
            b1.AddSnack(snacks[5], 2);  // 2x Large Cold Drink
            movies[0].AvailableSeats -= 2;
            bookings.Add(b1);

            // Preloaded booking 2 — Ayanda, 3 tickets, Inception, Cash, no discount
            Booking b2 = new Booking(GenerateBookingID(), movies[1], "Ayanda Dlamini", 3, "Cash", 0.0);
            b2.AddSnack(snacks[0], 3);  // 3x Small Popcorn
            b2.AddSnack(snacks[6], 3);  // 3x Bottled Water
            movies[1].AvailableSeats -= 3;
            bookings.Add(b2);

            // Preloaded booking 3 — Lerato, 1 ticket, The Notebook, Card, 15% student discount
            Booking b3 = new Booking(GenerateBookingID(), movies[2], "Lerato Mokoena", 1, "Card", 15.0);
            b3.AddSnack(snacks[10], 2); // 2x Chocolate Bar
            b3.AddSnack(snacks[4], 1);  // 1x Small Cold Drink
            movies[2].AvailableSeats -= 1;
            bookings.Add(b3);

            // Preloaded booking 4 — Sipho, 4 tickets, Avengers: Endgame, Crypto, 5% discount
            Booking b4 = new Booking(GenerateBookingID(), movies[5], "Sipho Mahlangu", 4, "Crypto", 5.0);
            b4.AddSnack(snacks[8], 2);  // 2x Nachos & Cheese
            b4.AddSnack(snacks[5], 4);  // 4x Large Cold Drink
            movies[5].AvailableSeats -= 4;
            bookings.Add(b4);

            // Preloaded booking 5 — Zanele, 2 tickets, Interstellar, Cash, no discount
            Booking b5 = new Booking(GenerateBookingID(), movies[6], "Zanele Khumalo", 2, "Cash", 0.0);
            b5.AddSnack(snacks[2], 2);  // 2x Caramel Popcorn
            b5.AddSnack(snacks[12], 2); // 2x Slushie
            movies[6].AvailableSeats -= 2;
            bookings.Add(b5);
        }

        // 3 preloaded cancelled bookings (seats already NOT deducted — they were restored on cancel)
        private void LoadCancelledBookings()
        {
            Booking c1 = new Booking(GenerateBookingID(), movies[3], "Mpho Sithole",   2, "Cash",   0.0);
            c1.AddSnack(snacks[9], 2);
            c1.IsCancelled = true;
            cancelledBookings.Add(c1);

            Booking c2 = new Booking(GenerateBookingID(), movies[4], "Nandi Zulu",     1, "Card",  10.0);
            c2.AddSnack(snacks[11], 1);
            c2.IsCancelled = true;
            cancelledBookings.Add(c2);

            Booking c3 = new Booking(GenerateBookingID(), movies[0], "Karabo Dlamin",  3, "Crypto", 0.0);
            c3.AddSnack(snacks[1], 3);
            c3.AddSnack(snacks[5], 3);
            c3.IsCancelled = true;
            cancelledBookings.Add(c3);
        }

        // Internal - unique booking ID generator
        internal string GenerateBookingID()
        {
            bookingCounter++;
            return "BK" + bookingCounter;
        }

        // ── Discount helper ───────────────────────────────────────────

        // Private - determines applicable discount for a customer
        private double DetermineDiscount(string customerName, int tickets)
        {
            double discount = 0.0;

            // Senior / student discount prompt
            Console.WriteLine("\n  --- DISCOUNT CHECK ---");
            Console.WriteLine("  Do you qualify for a discount?");
            Console.WriteLine("  1. Student (15% off)");
            Console.WriteLine("  2. Senior Citizen (20% off)");
            Console.WriteLine("  3. Group Booking 5+ tickets (10% off)");
            Console.WriteLine("  4. No discount");
            Console.Write("  Select: ");
            string discChoice = Console.ReadLine();

            switch (discChoice)
            {
                case "1":
                    discount = 15.0;
                    Console.WriteLine("  [✓] Student discount applied: 15%");
                    break;
                case "2":
                    discount = 20.0;
                    Console.WriteLine("  [✓] Senior discount applied: 20%");
                    break;
                case "3":
                    if (tickets >= 5)
                    {
                        discount = 10.0;
                        Console.WriteLine("  [✓] Group discount applied: 10%");
                    }
                    else
                    {
                        Console.WriteLine("  [!] Group discount requires 5+ tickets. No discount applied.");
                    }
                    break;
                default:
                    Console.WriteLine("  No discount applied.");
                    break;
            }

            return discount;
        }

        // ── Payment helper ────────────────────────────────────────────

        // Private - collect payment method from user
        private string CollectPaymentMethod(double amountDue)
        {
            Console.WriteLine("\n  --- PAYMENT ---");
            Console.WriteLine($"  Amount Due: R{amountDue:F2}");
            Console.WriteLine("  1. Cash");
            Console.WriteLine("  2. Card");
            Console.WriteLine("  3. Crypto");
            Console.Write("  Select payment method: ");

            string payChoice = Console.ReadLine();
            string method;

            switch (payChoice)
            {
                case "1":
                    method = "Cash";
                    Console.Write($"  Enter cash amount: R");
                    string cashInput = Console.ReadLine();
                    if (double.TryParse(cashInput, out double cashGiven) && cashGiven >= amountDue)
                    {
                        Console.WriteLine($"  [✓] Cash received: R{cashGiven:F2}");
                        Console.WriteLine($"  [✓] Change due:    R{cashGiven - amountDue:F2}");
                    }
                    else
                    {
                        Console.WriteLine("  [!] Insufficient cash — defaulting to Card.");
                        method = "Card";
                    }
                    break;
                case "2":
                    method = "Card";
                    Console.WriteLine("  [✓] Card payment authorised.");
                    break;
                case "3":
                    method = "Crypto";
                    Console.WriteLine("  [✓] Crypto payment confirmed on-chain.");
                    break;
                default:
                    method = "Cash";
                    Console.WriteLine("  [!] Invalid selection — defaulting to Cash.");
                    break;
            }

            return method;
        }

        // ── Snack ordering helper ──────────────────────────────────────

        // Private - let user add snacks to a booking
        private void OrderSnacks(Booking booking)
        {
            bool addingSnacks = true;

            while (addingSnacks)
            {
                Console.WriteLine("\n  --- SNACK BAR ---");
                Console.WriteLine("  " + string.Format("{0,-6} {1,-28} {2,8}   Category", "ID", "Item", "Price"));
                Console.WriteLine("  " + new string('-', 58));

                for (int i = 0; i < snacks.Length; i++)
                {
                    snacks[i].DisplayInfo();
                }

                Console.WriteLine("\n  Enter Snack ID to add (or press Enter to skip): ");
                Console.Write("  > ");
                string snackInput = Console.ReadLine().Trim().ToUpper();

                if (string.IsNullOrEmpty(snackInput))
                {
                    addingSnacks = false;
                    break;
                }

                Snack found = null;
                for (int i = 0; i < snacks.Length; i++)
                {
                    if (snacks[i].SnackID.ToUpper() == snackInput)
                    {
                        found = snacks[i];
                        break;
                    }
                }

                if (found == null)
                {
                    Console.WriteLine("  [!] Snack ID not found.");
                    continue;
                }

                Console.Write($"  How many {found.Name}? ");
                if (!int.TryParse(Console.ReadLine(), out int qty) || qty < 1)
                {
                    Console.WriteLine("  [!] Invalid quantity.");
                    continue;
                }

                booking.AddSnack(found, qty);
                Console.WriteLine($"  [✓] Added: {found.Name} x{qty}  R{found.Price * qty:F2}");

                Console.Write("  Add another snack? (yes/no): ");
                string more = Console.ReadLine().Trim().ToLower();
                if (more != "yes")
                    addingSnacks = false;
            }
        }

        // ── Public menu methods ───────────────────────────────────────

        // Display all movies — for loop + Array
        public void DisplayAllMovies()
        {
            Console.WriteLine("\n========================================");
            Console.WriteLine("           NOW SHOWING");
            Console.WriteLine("========================================\n");

            bool anyAvailable = false;
            for (int i = 0; i < movies.Length; i++)
            {
                if (movies[i].AvailableSeats > 0)
                {
                    movies[i].DisplayInfo(i + 1);
                    anyAvailable = true;
                }
            }

            if (!anyAvailable)
                Console.WriteLine("  No movies currently available.");
        }

        // Book tickets — if seat check + ArrayList + snacks + discount + payment
        public void BookTickets()
        {
            DisplayAllMovies();

            Console.Write("Enter movie number to book: ");
            string input = Console.ReadLine();

            if (!int.TryParse(input, out int choice) || choice < 1 || choice > movies.Length)
            {
                Console.WriteLine("\n  [!] Invalid movie selection.");
                return;
            }

            Movie selectedMovie = movies[choice - 1];

            if (selectedMovie.AvailableSeats == 0)
            {
                Console.WriteLine("\n  [!] Sorry, this movie is fully booked.");
                return;
            }

            Console.Write("Enter your name: ");
            string customerName = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(customerName))
            {
                Console.WriteLine("\n  [!] Name cannot be empty.");
                return;
            }

            Console.Write($"Enter number of tickets (available: {selectedMovie.AvailableSeats}): ");

            if (!int.TryParse(Console.ReadLine(), out int ticketCount) || ticketCount < 1)
            {
                Console.WriteLine("\n  [!] Invalid number of tickets.");
                return;
            }

            if (!selectedMovie.HasSeatsAvailable(ticketCount))
            {
                Console.WriteLine($"\n  [!] Only {selectedMovie.AvailableSeats} seats available.");
                return;
            }

            // Determine discount
            double discount = DetermineDiscount(customerName, ticketCount);

            // Create booking (payment collected after snacks so total is known)
            string bookingID = GenerateBookingID();
            Booking newBooking = new Booking(bookingID, selectedMovie, customerName, ticketCount, "Cash", discount);

            // Snack ordering
            Console.Write("\n  Would you like to add snacks? (yes/no): ");
            string wantSnacks = Console.ReadLine().Trim().ToLower();
            if (wantSnacks == "yes")
                OrderSnacks(newBooking);

            // Collect payment
            string payMethod = CollectPaymentMethod(newBooking.GrandTotal());
            newBooking.PaymentMethod = payMethod;

            // Deduct seats and save
            selectedMovie.AvailableSeats -= ticketCount;
            bookings.Add(newBooking);

            // Receipt
            Console.WriteLine("\n========================================");
            Console.WriteLine("         BOOKING CONFIRMED!");
            Console.WriteLine("========================================");
            newBooking.DisplayInfo();
            Console.WriteLine("========================================");
        }

        // View all active bookings — for loop + ArrayList
        public void ViewAllBookings()
        {
            Console.WriteLine("\n========================================");
            Console.WriteLine("          ACTIVE BOOKINGS");
            Console.WriteLine("========================================\n");

            if (bookings.Count == 0)
            {
                Console.WriteLine("  No active bookings.");
                return;
            }

            for (int i = 0; i < bookings.Count; i++)
            {
                Console.WriteLine($"  ---- Booking {i + 1} ----");
                Booking b = (Booking)bookings[i];
                b.DisplayInfo();
                Console.WriteLine();
            }
        }

        // View cancelled bookings history
        public void ViewCancelledBookings()
        {
            Console.WriteLine("\n========================================");
            Console.WriteLine("       CANCELLED BOOKINGS HISTORY");
            Console.WriteLine("========================================\n");

            if (cancelledBookings.Count == 0)
            {
                Console.WriteLine("  No cancelled bookings on record.");
                return;
            }

            for (int i = 0; i < cancelledBookings.Count; i++)
            {
                Console.WriteLine($"  ---- Cancelled #{i + 1} ----");
                Booking b = (Booking)cancelledBookings[i];
                b.DisplayInfo();
                Console.WriteLine();
            }
        }

        // Cancel a booking — if validate + ArrayList removal
        public void CancelBooking()
        {
            Console.WriteLine("\n========================================");
            Console.WriteLine("          CANCEL A BOOKING");
            Console.WriteLine("========================================");

            if (bookings.Count == 0)
            {
                Console.WriteLine("\n  No active bookings to cancel.");
                return;
            }

            Console.Write("Enter Booking ID to cancel: ");
            string bookingID = Console.ReadLine().Trim().ToUpper();

            Booking found = null;
            for (int i = 0; i < bookings.Count; i++)
            {
                Booking b = (Booking)bookings[i];
                if (b.BookingID.ToUpper() == bookingID)
                {
                    found = b;
                    break;
                }
            }

            if (found == null)
            {
                Console.WriteLine("\n  [!] Booking ID not found.");
                return;
            }

            Console.WriteLine("\n  Booking found:");
            found.DisplayInfo();

            Console.Write("\n  Confirm cancellation? (yes/no): ");
            string confirm = Console.ReadLine().Trim().ToLower();

            if (confirm == "yes")
            {
                found.Movie.AvailableSeats += found.NumberOfTickets;
                found.IsCancelled = true;
                bookings.Remove(found);
                cancelledBookings.Add(found);

                Console.WriteLine($"\n  [✓] Booking {found.BookingID} cancelled.");
                Console.WriteLine($"      {found.NumberOfTickets} seat(s) returned to {found.Movie.Title}.");
            }
            else
            {
                Console.WriteLine("\n  Cancellation aborted.");
            }
        }

        // Search movies by genre — if + for loop
        public void SearchByGenre()
        {
            Console.WriteLine("\n========================================");
            Console.WriteLine("       SEARCH MOVIES BY GENRE");
            Console.WriteLine("========================================");
            Console.WriteLine("\n  Genres: Action | Sci-Fi | Romance | Horror | Drama");
            Console.Write("\nEnter genre: ");

            string searchGenre = Console.ReadLine().Trim();

            if (string.IsNullOrWhiteSpace(searchGenre))
            {
                Console.WriteLine("\n  [!] Genre cannot be empty.");
                return;
            }

            Console.WriteLine($"\n  Results for \"{searchGenre}\":\n");
            bool foundAny = false;

            for (int i = 0; i < movies.Length; i++)
            {
                if (movies[i].Genre.Equals(searchGenre, StringComparison.OrdinalIgnoreCase))
                {
                    movies[i].DisplayInfo(i + 1);
                    foundAny = true;
                }
            }

            if (!foundAny)
                Console.WriteLine($"  No movies found for genre \"{searchGenre}\".");
        }

        // View snack menu
        public void ViewSnackMenu()
        {
            Console.WriteLine("\n========================================");
            Console.WriteLine("             SNACK BAR MENU");
            Console.WriteLine("========================================\n");
            Console.WriteLine("  " + string.Format("{0,-6} {1,-28} {2,8}   Category", "ID", "Item", "Price"));
            Console.WriteLine("  " + new string('-', 58));

            for (int i = 0; i < snacks.Length; i++)
                snacks[i].DisplayInfo();

            Console.WriteLine();
        }
    }
}
