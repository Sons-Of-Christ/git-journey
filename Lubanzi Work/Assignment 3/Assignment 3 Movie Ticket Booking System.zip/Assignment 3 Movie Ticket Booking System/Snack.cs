using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieBookingSystem
{
    public class Snack
    {
        // Private fields
        private string snackID;
        private string name;
        private string category;
        private double price;

        // Public properties
        public string SnackID
        {
            get { return snackID; }
            set { snackID = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Category
        {
            get { return category; }
            set { category = value; }
        }

        public double Price
        {
            get { return price; }
            set { price = value; }
        }

        // Constructor
        public Snack(string snackID, string name, string category, double price)
        {
            this.snackID = snackID;
            this.name = name;
            this.category = category;
            this.price = price;
        }

        // Protected method - subclasses (e.g., ComboSnack) could override label
        protected virtual string GetSnackLabel()
        {
            return $"[{category}] {name}";
        }

        // Internal method - checks if snack belongs to a category
        internal bool IsInCategory(string cat)
        {
            return category.Equals(cat, StringComparison.OrdinalIgnoreCase);
        }

        // Public display for the snack menu
        public void DisplayInfo()
        {
            Console.WriteLine($"  [{snackID}] {name,-28} R{price,6:F2}   ({category})");
        }
    }
}
