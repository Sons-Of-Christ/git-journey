using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieBookingSystem
{
    public class Booking
    {
        // Private fields
        private string bookingID;
        private Movie movie;
        private string customerName;
        private int numberOfTickets;
        private DateTime bookingTime;
        private string paymentMethod;   // Cash, Card, Crypto
        private double discountPercent; // e.g. 10.0 for 10%
        private ArrayList snackItems;   // List of SnackOrder objects
        private bool isCancelled;

        // Public properties
        public string BookingID
        {
            get { return bookingID; }
            set { bookingID = value; }
        }

        public Movie Movie
        {
            get { return movie; }
            set { movie = value; }
        }

        public string CustomerName
        {
            get { return customerName; }
            set { customerName = value; }
        }

        public int NumberOfTickets
        {
            get { return numberOfTickets; }
            set { numberOfTickets = value; }
        }

        public DateTime BookingTime
        {
            get { return bookingTime; }
        }

        public string PaymentMethod
        {
            get { return paymentMethod; }
            set { paymentMethod = value; }
        }

        public double DiscountPercent
        {
            get { return discountPercent; }
            set { discountPercent = value; }
        }

        public ArrayList SnackItems
        {
            get { return snackItems; }
        }

        public bool IsCancelled
        {
            get { return isCancelled; }
            set { isCancelled = value; }
        }

        // Constructor
        public Booking(string bookingID, Movie movie, string customerName, int numberOfTickets,
                       string paymentMethod = "Cash", double discountPercent = 0.0)
        {
            this.bookingID = bookingID;
            this.movie = movie;
            this.customerName = customerName;
            this.numberOfTickets = numberOfTickets;
            this.bookingTime = DateTime.Now;
            this.paymentMethod = paymentMethod;
            this.discountPercent = discountPercent;
            this.snackItems = new ArrayList();
            this.isCancelled = false;
        }

        // Public - add a snack order to this booking
        public void AddSnack(Snack snack, int qty)
        {
            snackItems.Add(new SnackOrder(snack, qty));
        }

        // Private - ticket subtotal before discount
        private double TicketSubtotal()
        {
            return movie.Price * numberOfTickets;
        }

        // Private - snack subtotal
        private double SnackSubtotal()
        {
            double total = 0;
            for (int i = 0; i < snackItems.Count; i++)
            {
                SnackOrder so = (SnackOrder)snackItems[i];
                total += so.LineTotal();
            }
            return total;
        }

        // Public - grand total after discount
        public double GrandTotal()
        {
            double subtotal = TicketSubtotal() + SnackSubtotal();
            double discountAmt = subtotal * (discountPercent / 100.0);
            return subtotal - discountAmt;
        }

        // Protected method - subclasses (e.g., GroupBooking) could override
        protected virtual string GetBookingType()
        {
            return "Standard Booking";
        }

        // Internal - check ownership
        internal bool BelongsTo(string name)
        {
            return customerName.Equals(name, StringComparison.OrdinalIgnoreCase);
        }

        // Public display
        public void DisplayInfo()
        {
            string status = isCancelled ? "  *** CANCELLED ***" : "";
            Console.WriteLine($"  Booking ID    : {bookingID}{status}");
            Console.WriteLine($"  Customer      : {customerName}");
            Console.WriteLine($"  Movie         : {movie.Title}");
            Console.WriteLine($"  Genre         : {movie.Genre}");
            Console.WriteLine($"  Tickets       : {numberOfTickets}");
            Console.WriteLine($"  Ticket Cost   : R{TicketSubtotal():F2}");

            if (snackItems.Count > 0)
            {
                Console.WriteLine($"  Snacks:");
                for (int i = 0; i < snackItems.Count; i++)
                {
                    SnackOrder so = (SnackOrder)snackItems[i];
                    Console.WriteLine($"    - {so.Snack.Name} x{so.Quantity}  R{so.LineTotal():F2}");
                }
                Console.WriteLine($"  Snack Cost    : R{SnackSubtotal():F2}");
            }

            double subtotal = TicketSubtotal() + SnackSubtotal();
            if (discountPercent > 0)
            {
                Console.WriteLine($"  Subtotal      : R{subtotal:F2}");
                Console.WriteLine($"  Discount      : {discountPercent:F0}%  -R{subtotal * discountPercent / 100:F2}");
            }

            Console.WriteLine($"  TOTAL         : R{GrandTotal():F2}");
            Console.WriteLine($"  Payment       : {paymentMethod}");
            Console.WriteLine($"  Booked On     : {bookingTime:dd MMM yyyy HH:mm}");
            Console.WriteLine($"  Type          : {GetBookingType()}");
        }
    }

    // ── Helper class nested in same file ─────────────────────────────
    public class SnackOrder
    {
        private Snack snack;
        private int quantity;

        public Snack Snack   { get { return snack; } }
        public int Quantity  { get { return quantity; } }

        public SnackOrder(Snack snack, int quantity)
        {
            this.snack = snack;
            this.quantity = quantity;
        }

        public double LineTotal()
        {
            return snack.Price * quantity;
        }
    }
}
